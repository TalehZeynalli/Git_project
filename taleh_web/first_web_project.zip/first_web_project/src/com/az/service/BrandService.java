package com.az.service;

import java.util.ArrayList;
import java.util.List;

import com.az.model.Product;

public class BrandService {

	public List<Product> getListProduct() {
		List<Product> list = new ArrayList<Product>(5);

		return list;

	}

}
